<!DOCTYPE html>
<html lang="en">
<head>
<?php $this->load->view('front/layout/head'); ?>
</head>
<body>
<!-- Header -->
<?php $this->load->view('front/layout/header.php'); ?>
<!-- End Header -->
 <div class="bredcrumb">
    <div class="container">
        <div class="display_table">
            <div class="v_middle">
                <h1>About Us</h1>
                <div class="bredcrumb_nav">
                    <a href="#">Home</a>  / About Us
                </div>
            </div>
        </div>
    </div>
</div>
<section class="abr_wrap">
    <div class="container">
    <div class="about_imag_with_text">
        <div class="image_abgt">
            <img src="<?php echo base_url('uploads/cms/'.$pagedata[0]->image1); ?>"/>
        </div>
        <h3><?php echo $pagedata[0]->field1; ?></h3>
        <p><?php echo $pagedata[0]->desc1; ?></p>        
        
    </div>
    </div>
</section> 
<?php $this->load->view('front/layout/footer.php') ?>    
</body>
</html>





