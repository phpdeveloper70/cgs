<!DOCTYPE html>
<html lang="en">
<head>
<?php $this->load->view('front/layout/head'); ?>
</head>
<body>
<!-- Header -->
<?php $this->load->view('front/layout/header.php'); ?>
<!-- End Header -->
    <?php if(count($SLIDERDATA)>0){ ?>
    <div class="banner_wrap">
        <div class="home_slider">
            <div class="owl-carousel home_banner">
				<?php foreach($SLIDERDATA as $slider){ ?>   
                <div class="item">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-4 align-self-center">
                                <div class="slider_contents">
                                    <div class="slider_c_head">
                                    <h3><?php echo $slider->title; ?></h3>
                                    </div>
                                    <div class="slider_p_color">
                                        <?php /*<p>Sippon - 3 Color <span class="red_circle"></span> <span class="blue_circle"></span></p>*/ ?>
                                    </div>
                                    <div class="slider_btns">
                                        <a href="<?php echo $slider->description; ?>" class="btn blue_btn">View More</a>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col-md-8">
                                <div class="slider_product_imgs">
                                    <img src="<?php echo base_url('uploads/slider/'.$slider->image); ?>" />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php } ?>                
            </div>
        </div>
    
    </div>
    <?php } ?>
    
<section class="abt_wrap">
    <div class="container">
        <div class="row">
            <div class="col-md-6 align-self-center">
                <div class="abt_img">
                    <img src="<?php echo base_url('uploads/cms/'.$pagedata[0]->image1); ?>" />
                </div>
            </div>
            
            <div class="col-md-6 align-self-center">
                <div class="about_contents">
                    <div class="section_head">
                        <h3><?php echo $pagedata[0]->field1; ?></h3>
                    </div>
                    <div class="paragraph">
                        <p><?php echo $pagedata[0]->desc1; ?></p>
                    </div>
                    <div class="abt_btns">
                        <a href="<?php echo base_url("about-us"); ?>" class="btn blue_btn">View More</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
    
    
<section class="discover">
    <div class="container">
        <div class="section_head center">
            <h3><?php echo $pagedata[0]->field2; ?></h3>
        </div>
        <div class="row ">
            <div class="col-md-8 px-lg-2 w-desktop-big">
                <div class="discover_img">
                <img src="<?php echo base_url('uploads/cms/'.$pagedata[0]->image2); ?>" />
                </div>
            </div>
            
            <div class="col-md-4 px-lg-2 w-desktop-right">
                <div class="discover_img">
                <img src="<?php echo base_url('uploads/cms/'.$pagedata[0]->image3); ?>" />
                </div>
            </div>
            
            
        </div>
        
        <div class="row">
            
             <div class="col-md-8 px-lg-2 w-desktop-big">
                 <div class="row">
                    <div class="col-md-5 w-small-first">
                        <div class="discover_img">
                        <img src="<?php echo base_url('uploads/cms/'.$pagedata[0]->image4); ?>" />
                        </div>
                     </div>
                     
                     <div class="col-md-7 w-small-sec">
                        <div class="discover_img">
                        <img src="<?php echo base_url('uploads/cms/'.$pagedata[0]->image5); ?>" />
                        </div>
                     </div>
                     
                 </div>
                
            </div>
            
            <div class="col-md-4 px-lg-2 w-desktop-right">
                <div class="discover_img">
                <img src="<?php echo base_url('uploads/cms/'.$pagedata[0]->image6); ?>" />
                </div>
            </div>
            
        </div>
        
    </div>
</section>   
    
    
<section class="top_prod">
    <div class="container">
        <div class="section_head center">
            <h3><?php echo $pagedata[0]->field8; ?></h3>
            <p><?php echo $pagedata[0]->desc2; ?> </p>
        </div>
        <div class="row px-lg-2">
            <div class="col-md-3 px-lg-2">
                <a href="#">
                <div class="top_P_img">
                    <img src="<?php echo base_url('assets/front/img'); ?>/t1.jpg" />
                    <div class="after_hov_veiw_m">
                        <div class="disp_table">
                            <div class="middle">
                                <i class="flaticon-view"></i>
                                <small>View More</small>
                            </div>
                        </div>
                        
                    </div>
                </div>
                </a>
            </div>
            
            <div class="col-md-3 px-lg-2">
                <a href="#">
                <div class="top_P_img">
                    <img src="<?php echo base_url('assets/front/img'); ?>/t2.jpg" />
                    <div class="after_hov_veiw_m">
                        <div class="disp_table">
                            <div class="middle">
                                <i class="flaticon-view"></i>
                                <small>View More</small>
                            </div>
                        </div>
                        
                    </div>
                </div>
                </a>
            </div>
            
            <div class="col-md-3 px-lg-2">
                <a href="#">
                <div class="top_P_img">
                    <img src="<?php echo base_url('assets/front/img'); ?>/t3.jpg" />
                    <div class="after_hov_veiw_m">
                        <div class="disp_table">
                            <div class="middle">
                                <i class="flaticon-view"></i>
                                <small>View More</small>
                            </div>
                        </div>
                        
                    </div>
                </div>
                </a>
            </div>
            
            <div class="col-md-3 px-lg-2">
                <a href="#">
                <div class="top_P_img">
                    <img src="<?php echo base_url('assets/front/img'); ?>/t4.jpg" />
                    <div class="after_hov_veiw_m">
                        <div class="disp_table">
                            <div class="middle">
                                <i class="flaticon-view"></i>
                                <small>View More</small>
                            </div>
                        </div>
                        
                    </div>
                </div>
                </a>
            </div>
            
            <div class="col-md-3 px-lg-2">
                <a href="#">
                <div class="top_P_img">
                    <img src="<?php echo base_url('assets/front/img'); ?>/t5.jpg" />
                    <div class="after_hov_veiw_m">
                        <div class="disp_table">
                            <div class="middle">
                                <i class="flaticon-view"></i>
                                <small>View More</small>
                            </div>
                        </div>
                        
                    </div>
                </div>
                </a>
            </div>
            
            <div class="col-md-3 px-lg-2">
                <a href="#">
                <div class="top_P_img">
                    <img src="<?php echo base_url('assets/front/img'); ?>/t6.jpg" />
                    <div class="after_hov_veiw_m">
                        <div class="disp_table">
                            <div class="middle">
                                <i class="flaticon-view"></i>
                                <small>View More</small>
                            </div>
                        </div>
                        
                    </div>
                </div>
                </a>
            </div>
            
            <div class="col-md-3 px-lg-2">
                <a href="#">
                <div class="top_P_img">
                    <img src="<?php echo base_url('assets/front/img'); ?>/t7.jpg" />
                    <div class="after_hov_veiw_m">
                        <div class="disp_table">
                            <div class="middle">
                                <i class="flaticon-view"></i>
                                <small>View More</small>
                            </div>
                        </div>
                        
                    </div>
                </div>
                </a>
            </div>
            
            <div class="col-md-3 px-lg-2">
                <a href="#">
                <div class="top_P_img">
                    <img src="<?php echo base_url('assets/front/img'); ?>/t8.jpg" />
                    <div class="after_hov_veiw_m">
                        <div class="disp_table">
                            <div class="middle">
                                <i class="flaticon-view"></i>
                                <small>View More</small>
                            </div>
                        </div>
                        
                    </div>
                </div>
                </a>
            </div>
            
            
        </div>   
        
        <div class="top_p_vew_m">
            <a href="#" class="btn blue_btn">View More</a>
        </div>
        
   
    </div>
</section>    
    
 <section class="testim">
    <div class="container">
        <div class="section_head center">
            <h3><?php echo $pagedata[0]->field9; ?></h3>
        </div>
        <?php if(count($TESTIMONIALSDATA)>0){ ?>
        <div class="testim_wrap">
            <div class="testimonials_slider owl-carousel">
				<?php foreach($TESTIMONIALSDATA as $test){ ?>
                <div class="item">
                    <div class="row justify-content-center">
                    <div class="col-md-9">
                    <div class="testm_box">
                        <div class="testm_thumb">
                            <img src="<?php echo base_url('assets/front/img'); ?>/testm_user.jpg" />
                        </div>
                        <div class="testm_author">
                            <h4><?php echo $test->title; ?></h4>
                            <?php /*<small>Strauss Sport</small>*/ ?>
                        </div>
                        <div class="testm_content">
                            <p><?php echo $test->description; ?></p>
                        </div>
                    </div>
                    </div>
                    </div>
                </div>
                <?php } ?>
            </div>
        </div>
        <?php } ?>
     </div>
</section>
<?php $this->load->view('front/layout/footer.php') ?>    
</body>
</html>





