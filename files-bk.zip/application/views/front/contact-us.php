<!DOCTYPE html>
<html lang="en">
<head>
<?php $this->load->view('front/layout/head'); ?>
</head>
<body>
<!-- Header -->
<?php $this->load->view('front/layout/header.php'); ?>
<!-- End Header -->
<div class="bredcrumb">
    <div class="container">
        <div class="display_table">
            <div class="v_middle">
                <h1>Contact Us</h1>
                <div class="bredcrumb_nav">
                    <a href="#">Home</a>  / Contact Us
                </div>
            </div>
        </div>
    </div>
</div> 
<section class="contact_wrap">
    <div class="container">
    <div class="row">
        <div class="col-md-6">
            <div class="contact_address">
                <div class="addter_qt">
                    <h4><?php echo $pagedata[0]->field1; ?></h4>
                    <p><?php echo $pagedata[0]->desc1; ?></p>
                </div>
                
                <div class="row">
                    <div class="col-md-1">
                    
                        <div class="address_ic"><i class="fa fa-map-o" aria-hidden="true"></i></div>
                    
                    </div>
                    <div class="col-md-11">
                    
                        <div class="address_detls"><?php echo $pagedata[0]->field2; ?></div>
                    
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-1">
                    
                        <div class="address_ic"><i class="fa fa-phone" aria-hidden="true"></i></div>
                    
                    </div>
                    <div class="col-md-11">
                    
                        <div class="address_detls"><?php echo $pagedata[0]->field3; ?></div>
                    
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-1">
                    
                        <div class="address_ic"><i class="fa fa-envelope" aria-hidden="true"></i></div>
                    
                    </div>
                    <div class="col-md-11">
                    
                        <div class="address_detls"><?php echo $pagedata[0]->field4; ?></div>
                    
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-1">
                    
                        <div class="address_ic"><i class="fa fa-globe" aria-hidden="true"></i></div>
                    
                    </div>
                    <div class="col-md-11">
                    
                        <div class="address_detls"><?php echo $pagedata[0]->field5; ?></div>
                    
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-md-6">
			<?php echo $this->session->flashdata('msg'); ?>
            <div class="contact_frm" method="post">
                <form action="" method="post">
                    <input class="form-control" type="text" name="name" placeholder="Name*" value="<?php echo set_value('name'); ?>">
					<?php echo form_error('name'); ?>
                    <input class="form-control" type="email" name="email" placeholder="Enter Your Email*" value="<?php echo set_value('email'); ?>">
					<?php echo form_error('email'); ?>
                    <input class="form-control" type="text" name="phone" placeholder="Mobile Number*" value="<?php echo set_value('phone'); ?>">
					<?php echo form_error('phone'); ?>
                    <textarea class="form-control" rows="5" name="message" placeholder="Eneter Your Comment Here"><?php echo set_value('message'); ?></textarea>
					<?php echo form_error('message'); ?>
                    <input type="submit" name="submit_contactus" value="Submit">
                </form>
            </div>
            
            
        </div>
    </div>
    </div>
</section>    
    
<div class="maps">
<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d224346.61368090275!2d77.06889950047503!3d28.527218143802674!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390cfd5b347eb62d%3A0x52c2b7494e204dce!2sNew+Delhi%2C+Delhi!5e0!3m2!1sen!2sin!4v1554926640367!5m2!1sen!2sin" width="100%" height="300px" frameborder="0" style="border:none; padding: 0px; margin: 0px;" allowfullscreen></iframe>    
</div>
<?php $this->load->view('front/layout/footer.php') ?>    
</body>
</html>





