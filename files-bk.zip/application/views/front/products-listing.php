<!DOCTYPE html>
<html lang="en">
   <head>
      <?php $this->load->view('front/layout/head'); ?>
   </head>
   <body>
      <!-- Header -->
      <?php $this->load->view('front/layout/header.php'); ?>
      <!-- End Header -->
      <div class="bredcrumb">
         <div class="container">
            <div class="display_table">
               <div class="v_middle">
                  <h1>Products</h1>
                  <div class="bredcrumb_nav">
                     <a href="#">Home</a>  / Products
                  </div>
               </div>
            </div>
         </div>
      </div>
      <section class="products_listing_page">
         <div class="container">
            <div class="row">
               <div class="col-md-3">
                  <div class="prod_sidebar">
                     <div class="cat_top_haed">
                        <h2>Category</h2>
                     </div>
                     <div class="sidenav-wrapper">
                        <ul>
						<?php $parent_cat = $this->category_model->get_category_by_parent(0); ?>
						<?php if(count($parent_cat)>0){ ?>
						<?php $i=0; foreach($parent_cat as $p_cat){ $i++; ?>
						<?php $child_cat = $this->category_model->get_category_by_parent($p_cat->id); ?>
                           <li class="drop_box">
                              <a href="#" class="expandable expanded"><?php echo $p_cat->title; ?></a>
							  <?php if(count($child_cat)>0){ ?>
                              <ul>
								<?php foreach($child_cat as $c_cat){ ?>
                                 <li><a href="<?php  echo base_url('products/?cat_id='.$c_cat->id); ?>"><?php echo $c_cat->title; ?></a></li>
								<?php } ?>
                              </ul>
							  <?php } ?>
                           </li>
						<?php } } ?>
                        </ul>
                     </div>
                  </div>
               </div>
               <div class="col-md-9">
                  <div class="prod_thumb_list">
                     <div class="top_list_hhead">
                        <div class="row">
                           <div class="col-md-8 align-self-center">
                              <div class="leftbla">
                                 <h3>Bags <span>(Showing 1 – 10 Products of 200 Products)</span></h3>
                              </div>
                           </div>
                           <div class="col-md-4 align-self-center">
                              <div class="serch_filters">
                                 <span>Sort by:</span>
                                 <form>
                                    <select>
                                       <option value="asc">Default</option>
                                       <option value="asc">Old Product</option>
                                       <option value="desc">New Product</option>
                                    </select>
                                 </form>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="row">
                        <!---item-->
                        <div class="col-md-4">
                           <div class="prod_list_box">
                              <div class="prod_img">
                                 <img src="img/products/product-listing_03.jpg" />
                              </div>
                              <div class="prod_tite">
                                 <h4>A02 - Transparent Folding Table Clock</h4>
                              </div>
                           </div>
                        </div>
                        <!---item-->                        
                        <?php /*<div class="view_more_btn">
                           <a href="#" class="btn btn_v_more">View More</a>
                           </div>*/ ?>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </section>
      <?php $this->load->view('front/layout/footer.php') ?>    
   </body>
</html>