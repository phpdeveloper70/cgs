<?php if(count($SLIDERDATA)>0): ?>
<div id="bootstrap-touch-slider" class="carousel bs-slider fade  control-round indicators-line" data-ride="carousel" data-pause="hover" data-interval="false" > 
<!-- Indicators -->
	<ol class="carousel-indicators">
		<?php $x=0; foreach($SLIDERDATA as $slider): ?>
		<li data-target="#bootstrap-touch-slider" data-slide-to="<?php echo $x; ?>" class="<?php echo($x==0)?'active':''; ?>"></li>
		<?php  $x++; endforeach; ?>
	</ol>  
	<!-- Wrapper For Slides -->
	<div class="carousel-inner" role="listbox">   
		<?php $y=0; foreach($SLIDERDATA as $slider): ?>
		<!-- Third Slide -->
		<div class="item <?php echo($y==0)?'active':''; ?>">      
		  <!-- Slide Background --> 
			<img src="<?php echo base_url('uploads/slider/'.$slider->image); ?>" alt="Bootstrap Touch Slider"  class="slide-image"/>
			<div class="bs-slider-overlay"></div>
			<div class="container">
				<div class="row"> 
				<!-- Slide Text Layer -->
					<div class="slide-text <?php echo home_slider_class($y); ?>">
						<h1 data-animation="animated zoomInRight">Design your<br>all-natural <br>soap in less <br>Than 5 minutes. </h1>
						<a href="#sliderBtns" class="btn btn-default custom-bg" data-animation="animated fadeInLeft">Shop Now</a> 
					</div>
				</div>
			</div>
		</div>
		<!-- End of Slide -->  
		<?php  $y++; endforeach; ?>    
	</div>
	<!-- End of Wrapper For Slides -->   
	<!-- Left Control --> 
	<a class="left carousel-control" href="#bootstrap-touch-slider" role="button" data-slide="prev"> <span class="fa fa-angle-left" aria-hidden="true"></span> <span class="sr-only">Previous</span> </a> 
	<!-- Right Control --> 
	<a class="right carousel-control" href="#bootstrap-touch-slider" role="button" data-slide="next"> <span class="fa fa-angle-right" aria-hidden="true"></span> <span class="sr-only">Next</span> </a> 
</div>
<?php endif; ?>