<?php if(isset($pagedata) && is_array($pagedata) ){ ?>
<title><?php echo $pagedata[0]->meta_title; ?></title>
<meta name="description" content="<?php echo $pagedata[0]->meta_description; ?>">
<meta name="keywords" content="<?php echo $pagedata[0]->meta_keywords; ?>">
<?php }else{ ?>
<title><?php echo WEBSITE_TITLE; ?></title>
<meta name="description" content="<?php echo WEBSITE_TITLE; ?>">
<meta name="keywords" content="<?php echo WEBSITE_TITLE; ?>">
<?php } ?>

<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/front/vendor/bootstrap/css/bootstrap.min.css') ?>">    
<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/front/vendor/font-awesome/css/font-awesome.min.css') ?>">    
<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/front/flate-icon/flaticon.css') ?>">    
<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/front/css/navik.menu.css') ?>">    
<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/front/css/owl.carousel.min.css') ?>">    
<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/front/css/custom.css') ?>">

