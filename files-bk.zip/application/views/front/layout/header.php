	<div class="navik-header header-shadow">
		<div class="container">

			<!-- Navik header -->
			<div class="navik-header-container">
				
				<!--Logo-->
                <div class="logo" data-mobile-logo="<?php echo base_url('assets/front'); ?>/demo/images/logo-dark.png" data-sticky-logo="<?php echo base_url('assets/front'); ?>/img/foo_logo.png">
                	<a href="<?php echo base_url(); ?>"><img src="<?php echo base_url('assets/front/img'); ?>/foo_logo.png" alt="logo"/></a>
				</div>
                
                <div class="search_forms">
                    <form action="<?php echo base_url("search"); ?>" method="get">
                        <input type="text" name="search" placeholder="Search" required >
                        <button type="submit" name="submit"><i class="fa fa-search"></i></button>
                    </form>
                </div>
				
				<!-- Burger menu -->
				<div class="burger-menu">
					<div class="line-menu line-half first-line"></div>
					<div class="line-menu"></div>
					<div class="line-menu line-half last-line"></div>
				</div>

				<!--Navigation menu-->
                <nav class="navik-menu menu-caret submenu-top-border submenu-scale">
                	<ul>
                    	<li class="current-menu"><a href="<?php echo base_url(); ?>">Home</a></li>
						<li><a href="<?php echo base_url('about-us'); ?>">About Us</a></li>
                        <li><a href="<?php echo base_url('products'); ?>">Products</a></li>
                        <li><a href="<?php echo base_url('contact-us'); ?>">Contact</a></li>
                    </ul>
                </nav>
                
                

			</div>

		</div>
	</div>