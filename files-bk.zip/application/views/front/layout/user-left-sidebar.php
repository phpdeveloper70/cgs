<aside class="setting-tab">
	<ul class="nav nav-pills nav-stacked custom-tab">
		<li class="active"><a href="<?php echo base_url('user/edit_profile'); ?>" >Edit Profile</a></li>
		<li><a href="<?php echo base_url('user/profile_picture'); ?>">Change Avatar</a></li>
		<li><a href="<?php echo base_url('user/change_password'); ?>">Change Password</a></li>
		<li><a href="#messages">List Message</a></li>
		<li><a href="#subscription">List Subscription</a></li>                
	</ul>
</aside>