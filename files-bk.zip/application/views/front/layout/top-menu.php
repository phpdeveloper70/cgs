<?php $first_level = $this->category_model->get_category_by_parent(0); ?>

<ul class="nav navbar-nav navbar-right">
  <li class="active"><a href="<?=base_url();?>">Home</a></li>
  <?php foreach($first_level as $first_cat){ ?>
  <?php $second_level = $this->category_model->get_category_by_parent($first_cat->id); ?>
  <li class="<?php echo(count($second_level)>0)?'dropdown custom-dropdown':''; ?>"> <a href="<?php echo base_url($first_cat->url_slug.'.html') ?>" class="<?php echo(count($second_level)>0)?'dropdown-toggle':''; ?>"><?php echo $first_cat->title; ?>
    <?php if(count($second_level)>0){ ?>
    <span style="display:none" class="pull-right dropmenu" onclick="return toggle_mobile_menu('<?php echo $first_cat->id; ?>')"><i class="fa fa-plus"></i></span>
    <?php } ?>
    </a>
    <?php if(count($second_level)>0){ ?>
    <ul class="<?php echo(count($second_level)>0)?'dropdown-menu second-drop':''; ?>" role="menu" id="cm<?php echo $first_cat->id; ?>">
      <?php foreach($second_level as $second_cat){ ?>
      <?php $third_level = $this->category_model->get_category_by_parent($second_cat->id); ?>
      <li class="<?php echo(count($third_level)>0)?'dropdown-submenu':''; ?>"><a href="<?php echo base_url($second_cat->url_slug.'.html') ?>" class="dropdown-toggle" ><?php echo $second_cat->title; ?>
        <?php if(count($third_level)>0){ ?>
        <span style="display:none" class="pull-right dropmenu" onclick="return toggle_mobile_menu('<?php echo $second_cat->id; ?>')"><i class="fa fa-plus"></i></span>
        <?php } ?>
        </a>
        <?php if(count($third_level)>0){ ?>
        <ul class="dropdown-menu" role="menu" id="cm<?php echo $second_cat->id; ?>">
          <?php foreach($third_level as $third_cat){ ?>
          <li><a href="<?php echo base_url($third_cat->url_slug.'.html') ?>"><?php echo $third_cat->title; ?></a></li>
          <?php } ?>
        </ul>
        <?php } ?>
      </li>
      <?php } ?>
    </ul>
    <?php } ?>
  </li>
  <?php } ?>
  <li><a href="<?=base_url()?>contact">Contact Us</a></li>
  <li>
    <?php $cart_content = $this->cart->contents(); ?>
    <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"> <i class="fa fa-shopping-cart"></i> <span class="badge"><?php echo count($cart_content); ?></span> </a>
    <?php $this->load->view('front/layout/header-cart-pop-up'); ?>
  </li>
</ul>
