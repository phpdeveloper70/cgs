<?php $footer = $this->cms_model->get_cms_by_id(10); ?>
<footer>
  <div class="container">
      <div class="row">
        <div class="col-md-3">
            <div class="foo_logo">
                <img src="<?php echo base_url('assets/front/img'); ?>/foo_logo.png" />
                <div class="foo_social">
                    <span>Follow us:</span>
                    <a href="<?php echo $footer[0]->field1; ?>" target="_blank"><i class="flaticon-facebook-2"></i></a>
                    <a href="<?php echo $footer[0]->field2; ?>" target="_blank"><i class="flaticon-twitter-logo-silhouette"></i></a>
                    <a href="<?php echo $footer[0]->field3; ?>" target="_blank"><i class="flaticon-instagram"></i></a>
                    <a href="<?php echo $footer[0]->field4; ?>" target="_blank"><i class="flaticon-youtube-logo-1"></i></a>
                </div>
            </div>
        </div>
        
        <div class="col-md-6">
            <div class="foo_subscribe">
                <p>Subscribe for newsletter</p>
                <form action="" method="post">
                    <input type="text" name="search" placeholder="Enter your email">
                    <button type="submit" name="submit"><i class="flaticon-right-arrow-1"></i></button>
                </form>
            </div>
        </div>
          
        <div class="col-md-3">
            <div class="foo_contact_info">
                <p><?php echo $footer[0]->field6; ?></p>
                <p><?php echo $footer[0]->field7; ?></p>
                <p><?php echo $footer[0]->field8; ?></p>
            </div>
        </div>
        
      </div>
    </div>
</footer>
<div class="copyright">
    <p><?php echo $footer[0]->field5; ?></p>
</div>
  
<script type="text/javascript" src="<?php echo base_url('assets/front/vendor/jquery/jquery.min.js') ?>"></script>    
<script type="text/javascript" src="<?php echo base_url('assets/front/vendor/bootstrap/js/bootstrap.bundle.min.js') ?>"></script>    
<script type="text/javascript" src="<?php echo base_url('assets/front/js/navik.menu.js') ?>"></script>    
<script type="text/javascript" src="<?php echo base_url('assets/front/js/owl.carousel.min.js') ?>"></script>    
<script type="text/javascript" src="<?php echo base_url('assets/front/js/custom.js') ?>"></script>
