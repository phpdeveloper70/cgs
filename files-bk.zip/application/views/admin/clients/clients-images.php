<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Tatvam | clients images</title>
  <?php $this->load->view('admin/layout/head_css'); ?>
  <?php $this->load->view('admin/layout/tiny-mce'); ?>
<style>
.users-list>li {
    width: auto;
	position: relative;
}
.users-list>li img {
	max-height: 88px;
    border-radius: 1%;
    max-width: 100px;
    height: auto;
	border: 3px solid #bfbfbf;
}
.users-list-name {
    position: absolute;
    top: 10px;
    right: 10px;
    color: #f4f4f4;
	border-radius: 0px;
}	
</style>
</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">
<?php $this->load->view('admin/layout/header'); ?>	
  <!-- Left side column. contains the logo and sidebar -->
<?php $this->load->view('admin/layout/sidebar'); ?>	
  

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>Manage Clients</h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo base_url('admin/dashboard'); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Manage Clients</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <!-- Info boxes -->
      <div class="box">
     <div class="box-body">
            <div class="box box-primary">            
            <!-- /.box-header -->
            <!-- form start -->
            <form role="form" method="post" id="form" autocomplete="off"  enctype="multipart/form-data">
              <div class="box-body">	
				<div class="form-group box box-success box-solid">
					<div class="box-header with-border">Images</div>
					<div class="box-body " >
						<?php if(count($IMAGES)>0){ ?>
						<ul class="users-list clearfix">
							<?php foreach($IMAGES as $image): ?>
							<li class="pro_img<?php echo $image->id; ?>">
								<img src="<?php echo base_url('uploads/clients/'.$image->image); ?>" alt="Product Image">
								<a class="users-list-name btn btn-danger btn-xs" onclick="return remove_image('<?php echo $image->id; ?>','<?php echo $image->image; ?>')"><i class="fa fa-fw fa-trash-o"></i></a>
							</li>
						<?php endforeach; ?>
						</ul>
						<?php } ?>
						<div id="append_image"></div>						
						<span class="clearfix"></span>
						<div class="col-md-2" style="margin-top:10px;">
							<a type="button" onclick="addImage();" class="btn btn-primary" title="Add Image"><i class="fa fa-plus-circle"></i> Add Image</a>
						</div>
					</div>	
				</div>
              </div>
              <!-- /.box-body -->
              <div class="box-footer">
                <button type="submit" class="btn btn-primary" name="submitform">Submit</button>
              </div>
            </form>
          </div>
            </div>
		</div>

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->  
<?php $this->load->view('admin/layout/footer'); ?>
</div>
<!-- ./wrapper -->
<?php $this->load->view('admin/layout/footer_js'); ?>
<script class="example">
$(document).ready(function(){
	$("form").on('click','.removedata',function(){
		 $(this).parents(".fille_group").remove();
	});	
});
function addImage()
{ 
	$('#append_image').append('<span class="fille_group"><div class="col-md-5"><input type="file" class="form-control" name="image[]" required></div><div class="col-md-3" style="padding-bottom:5px"><a class="btn btn-danger removedata"><i class="fa fa-fw fa-trash"></i></a></div><span>');
}


function remove_image(IMG_ID,IMG)
{
	var confirm_event = confirm('are you sure you want to delete this image?');
	if(confirm_event==true)
	{
		$.ajax({
			url:'<?php echo base_url('admin/clients/image_delete'); ?>',
			type:'POST',
			data:{'id':IMG_ID,'image':IMG},
			success: function(response)
			{
				if(response==1)
				{
					$(".pro_img"+IMG_ID).fadeOut(300, function(){ $(this).remove(); });
				}
				if(response==0)
				{
					alert('oops somthing wrong!');	
				}	
			}
		});
	}		
}

</script>
</body>
</html>
