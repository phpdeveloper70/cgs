<?php $module =$this->uri->segment(2); ?>
<aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">      
      <ul class="sidebar-menu">
        <li class="active treeview">
          <a href="#">
            <i class="fa fa-home"></i> <span>Dashboard</span>           
          </a>          
        </li>        
        
		
		<li class="treeview <?php echo($module=='slider')?'active':'' ?>">
			<a href="#">
				<i class="fa fa-image"></i> <span>Slider</span>
				<span class="pull-right-container">
					<i class="fa fa-angle-left pull-right"></i>
				</span>
			</a>
			<ul class="treeview-menu">
				<li><a href="<?php echo base_url('admin/slider/listing'); ?>"><i class="fa fa-circle-o"></i>All sliders</a></li>
				<li><a href="<?php echo base_url('admin/slider/add_new'); ?>"><i class="fa fa-circle-o"></i>Add New slider</a></li>
			</ul>		  
        </li>
		
		<li class="treeview <?php echo($module=='category')?'active':'' ?>">
			<a href="#">
				<i class="fa fa-asterisk"></i> <span>Categories</span>
				<span class="pull-right-container">
				<i class="fa fa-angle-left pull-right"></i>
				</span>
			</a>
			<ul class="treeview-menu">
				<li><a href="<?php echo base_url('admin/category/listing'); ?>"><i class="fa fa-circle-o"></i>All Category</a></li>
				<li><a href="<?php echo base_url('admin/category/add_new'); ?>"><i class="fa fa-circle-o"></i>Add New Category</a></li>
			</ul>		  
        </li>
		
		<li class="treeview">
          <a href="#">
            <i class="fa fa-clone"></i> <span>Products</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
			<li><a href="<?php echo base_url('admin/product/listing'); ?>"><i class="fa fa-circle-o"></i>All Products</a></li>
			<li><a href="<?php echo base_url('admin/product/add_new'); ?>"><i class="fa fa-circle-o"></i>Add New Product</a></li>
		  </ul>		  
        </li>
		
		<li class="treeview <?php echo($module=='cms')?'active':'' ?>">
          <a href="#">
            <i class="fa fa-file"></i> <span>CMS Pages </span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo base_url('admin/cms/listing'); ?>"><i class="fa fa-circle-o"></i>All Pages</a></li>
			<li>#</li>
          </ul>		  
        </li>		
        
		
		<li class="treeview">
          <a href="#">
            <i class="fa fa-cubes"></i> <span>Testimonials </span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo base_url('admin/testimonial/listing'); ?>"><i class="fa fa-circle-o"></i>All Testimonials</a></li>
			<li><a href="<?php echo base_url('admin/testimonial/add_new'); ?>"><i class="fa fa-circle-o"></i>Add New</a></li>
		  </ul>		  
        </li>
      </ul>
    </section>
    <!-- /.sidebar -->
  </aside>
