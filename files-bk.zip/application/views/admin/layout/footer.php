  <footer class="main-footer">    
    <strong>Copyright &copy; <?php echo date('Y'); ?> <a href="">Soap</a>.</strong> All rights
    reserved.
  </footer>