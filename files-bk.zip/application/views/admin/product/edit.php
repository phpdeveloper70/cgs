<!DOCTYPE html>
<html>
   <head>
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <title><?php echo ADMINTITLE; ?></title>
      <?php $this->load->view('admin/layout/head_css'); ?>
      <?php $this->load->view('admin/layout/tiny-mce'); ?>
      <style>
         .users-list>li {
         width: auto;
         position: relative;
         }
         .users-list>li img {
         border-radius: 1%;
         max-width: 100px;
         height: auto;
         border: 3px solid #bfbfbf;
         }
         .users-list-name {
         position: absolute;
         top: 10px;
         right: 10px;
         color: #f4f4f4;
         border-radius: 0px;
         }	
      </style>
   </head>
   <body class="hold-transition skin-blue sidebar-mini">
      <div class="wrapper">
         <?php $this->load->view('admin/layout/header'); ?>	
         <!-- Left side column. contains the logo and sidebar -->
         <?php $this->load->view('admin/layout/sidebar'); ?>	
         <!-- Content Wrapper. Contains page content -->
         <div class="content-wrapper">
            <!-- Content Header (Page header) -->
            <section class="content-header">
               <h1>Edit Product</h1>
               <ol class="breadcrumb">
                  <li><a href="<?php echo base_url('admin/dashboard'); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
                  <li><a href="<?php echo base_url('admin/product/listing'); ?>">All Product</a></li>
                  <li class="active">Edit Product</li>
               </ol>
            </section>
            <!-- Main content -->
            <section class="content">
               <!-- Info boxes -->
               <div class="box">
                  <div class="box-body">
                     <div class="box box-primary">
                        <!-- /.box-header -->
                        <!-- form start -->
                        <form role="form" method="post" id="form" autocomplete="off"  enctype="multipart/form-data">
                           <div class="box-body">
                              <div class="form-group">
                                 <label for="exampleInputPassword1">Select Category</label>
                                 <select class="form-control" name="cat_id" id="select_cat" required>
                                    <option value=''>select Category</option>
                                    <?php echo $this->category_model->get_all_child_category(0); ?>
                                 </select>
                                 <?php echo form_error('cat_id'); ?>
                              </div>
                              <div class="form-group">
                                 <label for="exampleInputEmail1">Title</label>
                                 <input type="text" class="form-control" name="title" onkeyup="return set_slug(this.value);" value="<?php echo $RESULT[0]->title; ?>" required placeholder="Enter Title">				  
                                 <?php echo form_error('title'); ?>
                              </div>
							  <div class="form-group">
								<label for="exampleInputEmail1">Image</label>
								<input type="file" class="form-control" name="image">
								<input type="hidden" name="old_file" value="<?php echo $RESULT[0]->image; ?>" >
								<?php if(!empty($RESULT[0]->image)){ ?>
								<img src="<?php echo base_url('uploads/product/').$RESULT[0]->image; ?>" width="20%">
								<?php } ?>
							</div>
                            
							<div class="form-group">
                                 <label for="exampleInputEmail1">Product Code</label>
                                 <input type="text" class="form-control" name="product_code"  value="<?php echo $RESULT[0]->product_code; ?>" required placeholder="Enter Product Code">				  
                                 <?php echo form_error('product_code'); ?>
                              </div>					  
							  
							  <div class="form-group">
                              <label for="exampleInputPassword1">Availability</label>
                              <select class="form-control" name="stock" required>
                                 <option <?php echo($RESULT[0]->stock=='In Stock')?'selected':''; ?> value='In Stock'>In Stock</option>
                                 <option <?php echo($RESULT[0]->stock=='Out of Stock')?'selected':''; ?> value='Out of Stock'>Out of Stock</option>
                              </select>
                              <?php echo form_error('stock'); ?>
							  </div>
							
							
                              <div class="form-group">
                                 <label for="exampleInputEmail1">Description</label>
                                 <textarea class="form-control" name="description" placeholder="Enter description"><?php echo $RESULT[0]->description; ?></textarea>
                              </div>
                              <div class="form-group">
                                 <label for="exampleInputEmail1">Meta Title</label>
                                 <input type="text" class="form-control" name="meta_title" value="<?php echo $RESULT[0]->meta_title; ?>" required placeholder="Enter Meta Title">				  
                                 <?php echo form_error('meta_title'); ?>
                              </div>
                              <div class="form-group">
                                 <label for="exampleInputEmail1">Meta Keywords</label>
                                 <textarea class="form-control" name="meta_keywords" placeholder="Enter description" ><?php echo $RESULT[0]->meta_keywords; ?></textarea>
                              </div>
                              <div class="form-group">
                                 <label for="exampleInputEmail1">Meta Description</label>
                                 <textarea class="form-control" name="meta_description" placeholder="Enter description"><?php echo $RESULT[0]->meta_description; ?></textarea>
                              </div>
                              
                              <div class="form-group box box-success box-solid">
                                 <div class="box-header with-border">Related Products</div>
                                 <div class="box-body " style="max-height: 200px; overflow-y: scroll;" >
                                    <?php  $rel_products = $RESULT[0]->related_products; 
                                       $array_data= json_decode($rel_products, true);
                                       $all_products = (!is_array($array_data))?array(0):$array_data;					
                                       ?>
                                    <?php foreach($PRODCTS as $pro){ ?>
                                    <?php if($RESULT[0]->id==$pro->id){ }else{?>	
                                    <div class="form-check">
                                       <label>
                                       <input type="checkbox" name="pro_list[]" value="<?=$pro->id?>" <?php echo (in_array($pro->id, $all_products))  ? 'checked' : '';?>> 
                                       <span class="label-text"><?=$pro->title?></span>
                                       </label>
                                    </div>
                                    <?php }}?>
                                 </div>
                              </div>
                           </div>
                           
                     </div>
                     <div class="form-group ">
                     <label for="sel1">Is Latest ?</label>
                     <select class="form-control" id="sel1" name="is_latest">
                     <option value="no" <?php echo($RESULT[0]->is_latest=='no')?'selected':''; ?>> No</option>
                     <option value="yes" <?php echo($RESULT[0]->is_latest=='yes')?'selected':''; ?>>Yes</option>
                     </select>
                     </div>
                     <div class="form-group ">
                     <label for="exampleInputPassword1">Status</label>
                     <select class="form-control" name="status" required>
                     <option value='1' <?php echo($RESULT[0]->status==1)?'selected':''; ?> >Active</option>
                     <option value='0' <?php echo($RESULT[0]->status==0)?'selected':''; ?>>Inactive</option>
                     </select>
                     <?php echo form_error('status'); ?>
                     </div> 
                  </div>
                  <!-- /.box-body -->
                  <div class="box-footer">
                  <button type="submit" class="btn btn-primary" name="submitform">Submit</button>
                  </div>
                  </form>
               </div>
         </div>
      </div>
      </section>
      <!-- /.content -->
      </div>
      <!-- /.content-wrapper -->  
      <?php $this->load->view('admin/layout/footer'); ?>
      </div>
      <!-- ./wrapper -->
      <?php $this->load->view('admin/layout/footer_js'); ?>
      <script src="<?php echo base_url('assets/admin/parsley/parsley.js'); ?>"></script>
      <script class="example">
         $(document).ready(function(){
         	$('#form').parsley();
         	$('#select_cat').val('<?php echo $RESULT[0]->cat_id; ?>').change();
         	
         	$("form").on('click','.removedata',function(){
         		 $(this).parents(".fille_group").remove();
         	});	
         });
         function addImage()
         { 
         	$('#append_image').append('<span class="fille_group"><div class="col-md-5"><input type="file" class="form-control" name="image[]" required></div><div class="col-md-3" style="padding-bottom:5px"><a class="btn btn-danger removedata"><i class="fa fa-fw fa-trash"></i></a></div><span>');
         }
         
         function set_slug(VALUE)
         {
         	$("#url_slug").val(string_to_slug(VALUE));
         }
         
         function string_to_slug(str) {
             str = str.replace(/^\s+|\s+$/g, ''); // trim
             str = str.toLowerCase();  
             // remove accents, swap ñ for n, etc
             var from = "àáäâèéëêìíïîòóöôùúüûñç·/_,:;";
             var to   = "aaaaeeeeiiiioooouuuunc------";
             for (var i=0, l=from.length ; i<l ; i++) {
                 str = str.replace(new RegExp(from.charAt(i), 'g'), to.charAt(i));
             }
             str = str.replace(/[^a-z0-9 -]/g, '') // remove invalid chars
                 .replace(/\s+/g, '-') // collapse whitespace and replace by -
                 .replace(/-+/g, '-'); // collapse dashes
             return str;
         }
         
         function remove_image(IMG_ID,IMG)
         {
         	var confirm_event = confirm('are you sure you want to delete this image?');
         	if(confirm_event==true)
         	{
         		$.ajax({
         			url:'<?php echo base_url('admin/product/image_delete'); ?>',
         			type:'POST',
         			data:{'id':IMG_ID,'image':IMG},
         			success: function(response)
         			{
         				if(response==1)
         				{
         					$(".pro_img"+IMG_ID).fadeOut(300, function(){ $(this).remove(); });
         				}
         				if(response==0)
         				{
         					alert('oops somthing wrong!');	
         				}	
         			}
         		});
         	}		
         }
         
      </script>
   </body>
</html>