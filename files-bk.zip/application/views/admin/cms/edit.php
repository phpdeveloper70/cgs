<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title><?php echo ADMINTITLE; ?></title>
  <?php $this->load->view('admin/layout/head_css'); ?>
  <?php $this->load->view('admin/layout/tiny-mce'); ?>
</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">
<?php $this->load->view('admin/layout/header'); ?>
  <!-- Left side column. contains the logo and sidebar -->
<?php $this->load->view('admin/layout/sidebar'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>Edit Cms Page</h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo base_url('admin/dashboard'); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Edit Cms Page</li>
      </ol>
    </section>
<?php $fields_data = json_decode($RESULT[0]->fields,TRUE); ?>
    <!-- Main content -->
    <section class="content">
      <!-- Info boxes -->
		<div class="box">
		<div class="box-body">
            <div class="box box-primary">
            <!-- /.box-header -->
            <!-- form start -->
            <form role="form" method="post" id="form" enctype="multipart/form-data">
              <div class="box-body">
                <div class="form-group">
                  <label for="exampleInputEmail1">Title</label>
                  <input type="text" class="form-control" name="title" required placeholder="Enter Title" value="<?php echo $RESULT[0]->title; ?>" readonly >
                </div>
				<?php if(!empty($fields_data) && is_array($fields_data)){ ?>
				<?php foreach($fields_data as $key => $val){?>
				<?php if($val['type']=='text'){ ?>
                <div class="form-group">
					<label for="exampleInputEmail1"><?php echo ucfirst($val['title']); ?></label>
					<input type="text" class="form-control" name="<?php echo $key; ?>" value="<?php echo get_field_val($RESULT[0],$key); ?>" required	>
				</div>
				<?php } ?>
				<?php if($val['type']=='textarea'){ ?>
                <div class="form-group">
					<label for="exampleInputEmail1"><?php echo ucfirst($val['title']); ?></label>
					<textarea class="form-control" name="<?php echo $key; ?>" ><?php echo get_field_val($RESULT[0],$key); ?></textarea>
				</div>
				<?php } ?>

				<?php if($val['type']=='file'){ ?>
                <div class="form-group">
					<label for="exampleInputEmail1"><?php echo ucfirst($val['title']); ?></label>
					<input type="file" class="form-control" name="<?php echo $key; ?>" 	>
					<img src="<?php echo base_url(); ?>uploads/cms/<?php echo get_field_val($RESULT[0],$key); ?>" width="70">
					<input type="hidden" name="<?php echo $key; ?>_old" value="<?php echo get_field_val($RESULT[0],$key); ?>">
				</div>
				<?php } // end if ?>
				<?php } //end foreach ?>
				<?php } //end if ?>
				<div class="form-group">
                  <label for="exampleInputEmail1">Meta Title</label>
                  <input type="text" class="form-control" name="meta_title" required placeholder="Enter meta title" value="<?php echo $RESULT[0]->meta_title; ?>">
                </div>
				<div class="form-group">
                  <label for="exampleInputEmail1">Meta Keyword</label>
				  <input type="text" class="form-control" name="meta_keywords" required placeholder="Enter meta Keywords" value="<?php echo $RESULT[0]->meta_keywords; ?>">
                </div>
				<div class="form-group">
                  <label for="exampleInputEmail1">Meta description</label>
				   <input type="text" class="form-control" name="meta_description" required placeholder="Enter meta description" value="<?php echo $RESULT[0]->meta_description; ?>">
                </div>
                <div class="form-group">
                  <label for="exampleInputPassword1">Status</label>
                  <select class="form-control" name="status" required>
					<option value='1' <?php echo($RESULT[0]->status==1)?'selected':''; ?>>Active</option>
					<option value='0' <?php echo($RESULT[0]->status==0)?'selected':''; ?>>Inactive</option>
				  </select>
                </div>
              </div>
              <!-- /.box-body -->
              <div class="box-footer">
                <button type="submit" class="btn btn-primary" name="submitform">Update</button>
              </div>
            </form>
			</div>
        </div>
		</div>

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php $this->load->view('admin/layout/footer'); ?>
</div>
<!-- ./wrapper -->
<?php $this->load->view('admin/layout/footer_js'); ?>
<script src="<?php echo base_url('assets/admin/parsley/parsley.js'); ?>"></script>
<script class="example">
$(document).ready(function(){
	$('#form').parsley();
});
</script>
</body>
</html>
