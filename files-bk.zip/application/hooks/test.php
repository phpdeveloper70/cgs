<?php 
class notification{
	
	public function get_notification()
	{
		print_r(func_get_args());
	}
	
}
?>