<?php
class Product extends CI_Controller
{
	function index()
	{
		if(isset($_GET['cat_id']) && $_GET['cat_id']!="")
		{
			$cat_id = $_GET['cat_id'];
		}else{ $cat_id = "";  }
		
		$this->load->view("front/products-listing");
	}	
}
