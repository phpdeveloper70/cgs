<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Contact extends CI_Controller{
	
	function index()
	{
		
		if(isset($_POST['submit']))
		{
			//print_r($_POST);	
		 $from_email = "info@graphicsmrlin.com"; 
         $name = $this->input->post('name'); 
		 $to_email = $this->input->post('email');
		 $mobile = $this->input->post('mobile');
		 $messages = $this->input->post('message');
   
         //Load email library 
         $this->load->library('email'); 
   
         $this->email->from($from_email, $name); 
         $this->email->to($to_email);
		 $this->email->set_mailtype("html");
         $this->email->subject('Contact Us'); 
		 
		  $message = '<html><body>';
			$message .= '<table rules="all" style="border-color: #666;" cellpadding="10">';
			$message .= "<tr style='background: #eee;'><td colspan='2'>Contact Us</td></tr>";
			$message .= "<tr><td><strong>Name:</strong> </td><td>" . $name . "</td></tr>";
			$message .= "<tr><td><strong>Email:</strong> </td><td>" . $to_email . "</td></tr>";
			$message .= "<tr><td><strong>Mobile:</strong> </td><td>" . $mobile . "</td></tr>";
			$message .= "<tr><td><strong>Message:</strong> </td><td>" . $messages . "</td></tr>";
			$message .= "</table>";
			$message .= "</body></html>";
         $this->email->message($message); 
   
         //Send mail 
         if($this->email->send()) 
		 
		 $this->session->set_flashdata('msg','<div class="alert alert-success">Email sent successfully.</div>');
        // $this->session->set_flashdata("email_sent","Email sent successfully."); 
         else 
         $this->session->set_flashdata("email_sent","Error in sending Email."); 
         $this->load->view('front/contact'); 
		
		}
	$this->load->view('front/contact');
	
		}
	
}
