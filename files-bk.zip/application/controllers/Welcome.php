<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller
{

	public function index()
	{	 
		$this->load->model(array('slider_model','testimonial_model'));
		$data['SLIDERDATA'] = $this->slider_model->get_all_active_slider();
		$data['TESTIMONIALSDATA'] = $this->testimonial_model->get_all_active_testimonial();
		$data['LATESTPRO'] = $this->product_model->get_all_latest_product(10);
		$data['pagedata'] = $this->cms_model->get_cms_by_id(1);
		$this->load->view('front/home',$data);
	}
	
	function about_us()
	{
		$data['pagedata'] = $this->cms_model->get_cms_by_id(2);
		$this->load->view('front/about-us',$data);
	}
	
	function contact_us()
	{
		
		if(isset($_POST['submit_contactus']))
		{
			$this->form_validation->set_rules('name', 'name', 'trim|required');
			$this->form_validation->set_rules('email', 'email address', 'trim|required');
			$this->form_validation->set_rules('phone', 'mobile no.', 'trim|required');
			$this->form_validation->set_rules('message', 'message', 'trim|required');
			$this->form_validation->set_error_delimiters('<div class="error"><i class="fa fa-warning"></i>&nbsp', '</div>');
			if($this->form_validation->run() == TRUE)
			{
					//Load email library 
					$this->load->library('email'); 
		   
					$this->email->from('phpdeveloper70@gmail.com', $_POST['name']); 
					$this->email->to($_POST['email']);
					$this->email->set_mailtype("html");
					$this->email->subject('Contact Us Enquiry'); 				 
					$message = '<html><body>';
					$message .= '<table rules="all" style="border-color: #666;" cellpadding="10">';
					$message .= "<tr style='background: #eee;'><td colspan='2'>Contact Us Enquiry</td></tr>";
					$message .= "<tr><td><strong>Name:</strong> </td><td>" . $_POST['name'] . "</td></tr>";
					$message .= "<tr><td><strong>Email:</strong> </td><td>" . $_POST['email'] . "</td></tr>";
					$message .= "<tr><td><strong>Mobile No.:</strong> </td><td>" . $_POST['phone'] . "</td></tr>";
					$message .= "<tr><td><strong>Message:</strong> </td><td>" . $_POST['message'] . "</td></tr>";
					$message .= "</table>";
					$message .= "</body></html>";
					$this->email->message($message); 
					$this->email->send();
					$this->session->set_flashdata('msg','<div class="alert alert-success">Your message has been successfully sent. We will contact you very soon!</div>');
					redirect("contact-us");
			}	
		}	
		
		$data['pagedata'] = $this->cms_model->get_cms_by_id(9);
		$this->load->view('front/contact-us',$data);
	}
	
	function search_product()
    {
				if(isset($_GET['q']) && !empty($_GET['q']))
				{
					$data['PRODUCTS'] = $this->product_model->search_products($_GET['q']);
				}
				else
				{
					$data['PRODUCTS'] = array();
				}

				$this->load->view('front/product/search',$data);
    }
}
