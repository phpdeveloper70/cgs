<?php
class Category extends CI_Controller{
	
	function product_listing()
	{
		echo "okk";
	}
	
}
