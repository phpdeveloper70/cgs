<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller 
{
	function __construct()
	{
		parent::__construct();
		$this->load->model('admin_model');
	}
	
	public function index()
	{
		$this->check_admin_login('IS_LOGIN');
		if(isset($_POST['login']))
		{
			$email = $this->input->post('email');
			$password = $this->input->post('password');
			if(empty($email) || empty($password))
			{
				$this->session->set_flashdata('msg','<div class="alert alert-danger">Invalid login credentials. please try again</div>');
				redirect('admin');
			}
			else
			{
				$rows = $this->admin_model->admin_login($email,$password);
				if(count($rows)==1)
				{
					if($rows[0]->status==0)
					{
						$this->session->set_flashdata('msg','<div class="alert alert-warning">Your account has been disabled. Please contact your system administrator.</div>');
						redirect('admin/');
					}
					else
					{
						$admin_data = array('ADMIN_ID'=>$rows[0]->id,'ADMIN_ROLE'=>$rows[0]->role,'ADMIN_EMAIL'=>$rows[0]->email);
						$this->session->set_userdata($admin_data);
						redirect('admin/dashboard');
					}
				}
				else
				{
					$this->session->set_flashdata('msg','<div class="alert alert-danger">Invalid login credentials. please try again</div>');
					redirect('admin');
				}
			}
		}	
		$this->load->view('admin/login');
	}
	
	public function dashboard()
	{
		$this->check_admin_login('IS_NOT_LOGIN');
		$data['All_CATEGORY'] = $this->category_model->get_all_category();
		$data['ACTIVE_PRODUCTS'] = $this->product_model->get_all_product('1');
		$this->load->view('admin/dashboard',$data);
	}
	
	public function change_password()
	{
		$this->check_admin_login('IS_NOT_LOGIN');
		if(isset($_POST['submitform']))
		{
			$npwd = $this->input->post('npwd');
			$cpwd = $this->input->post('cpwd');
			if(!empty($npwd) && !empty($cpwd))
			{
				if($npwd!=$cpwd)
				{
					$this->session->set_flashdata('msg','<div class="alert alert-danger">New password and confirm password not match!</div>');
					redirect('admin/change_password');
				}
				else
				{
					$admin_id = $this->session->userdata('ADMIN_ID');
					$update_data['password'] = base64_encode($npwd);
					$this->admin_model->update_admin_by_id($admin_id,$update_data);
					$this->session->set_flashdata('msg','<div class="alert alert-success">your password has been changed successfully!</div>');
					redirect('admin/change_password');
				}
			}
			else
			{
				$this->session->set_flashdata('msg','<div class="alert alert-danger">password fields cannot be empty!</div>');
				redirect('admin/change_password');
			}	
		}	
		
		
		$this->load->view('admin/change-password');
	}
	
	function forgot_password()
	{
		if(isset($_POST['forgot_password']))
		{
			$email = $_POST['email'];
			if(!empty($email))
			{
				$admin_data = $this->admin_model->admin_login_by_email($email);
				if(count($admin_data)>0)
				{ 
					$token = sha1(time().base64_encode(time()));					
					$update_data['forgot_token'] = $token;
					$this->admin_model->update_admin_by_id($admin_data[0]->id,$update_data);
					
					$message = 'Dear Admin,<br>';
					$message .= 'Please click bellow link to reset your password.';
					$message .= '<br><a href="'.base_url('admin/admin/reset_password/'.$token).'"><strong>Click Here <strong></a> or <br>'.base_url('admin/admin/reset_password/'.$token);

					$to   = $admin_data[0]->email;	
					$this->load->library('email'); 
					$this->email->set_mailtype("html");
					$this->email->set_newline("\r\n");
					$this->email->from(FROM_EMAIL, 'Forgot Password'); 
					$this->email->to($to);
					$this->email->subject(WEBSITE_TITLE. ' Reset your Password"'); 
					$this->email->message($message);	
					$this->email->send(); 
					$this->session->set_flashdata('msg','<div class="alert alert-success">you will receive an email with a link to reset your password.</div>');
					redirect('admin/admin/forgot_password');
				}
				else
				{
					$this->session->set_flashdata('msg','<div class="alert alert-danger">you have entered an invalid email address. please try again!</div>');
					redirect('admin/admin/forgot_password');
				}				
			}
			else
			{
				$this->session->set_flashdata('msg','<div class="alert alert-danger">Please enter valid email!</div>');
				redirect('admin/admin/forgot_password');
			}	
		}	
		$this->load->view('admin/forgot-password');
	}
	
	function reset_password()
	{
		$args = func_get_args();
		if(count($args)>0)
		{
			$admin_data = $this->admin_model->admin_login_by_forgot_token($args[0]);
			if(count($admin_data)==0)
			{	
				$this->session->set_flashdata('msg','<div class="alert alert-danger">Token expired!</div>');
				redirect('admin');
			}else
			{
				if(isset($_POST['reset_password']))
				{
					$npwd = $this->input->post('npwd');
					$cpwd = $this->input->post('cpwd');
					if(!empty($npwd) && !empty($cpwd))
					{
						if($npwd!=$cpwd)
						{
							$this->session->set_flashdata('msg','<div class="alert alert-danger">New password and confirm password not match!</div>');
							redirect('admin/admin/reset_password/'.$args[0]);
						}
						else
						{							
							$update_data['password'] = base64_encode($npwd);
							$update_data['forgot_token'] = '';
							$this->admin_model->update_admin_by_id($admin_data[0]->id,$update_data);
							$this->session->set_flashdata('msg','<div class="alert alert-success">your password has been changed successfully!</div>');
							redirect('admin');
						}
					}
					else
					{
						$this->session->set_flashdata('msg','<div class="alert alert-danger">password fields cannot be empty!</div>');
						redirect('admin/admin/reset_password/'.$args[0]);
					}	
				}
				
				$this->load->view('admin/reset-password');
			}	
		}
		else
		{
			$this->session->set_flashdata('msg','<div class="alert alert-danger">Token expired!</div>');
			redirect('admin');
		}	
	}
	
	public function manage_newslatter()
	{
		$this->check_admin_login('IS_NOT_LOGIN');		
		$this->load->model('newslatter_model');		
		$data['RESULT'] = $this->newslatter_model->get_all_newslatter();		
		$this->load->view('admin/newslatter/listing',$data);
	}
	
	public function delete_newslatter()
	{
		$args = func_get_args();
		$this->check_admin_login('IS_NOT_LOGIN');		
		$this->load->model('newslatter_model');		
		$this->newslatter_model->delete_newslatter_by_id($args[0]);
		$this->session->set_flashdata('msg','<div class="alert alert-success">record has been successfully deleted.</div>');
		redirect('admin/admin/manage_newslatter');
	}
	
	public function logout()
	{
		$this->session->unset_userdata('ADMIN_ID');
		$this->session->unset_userdata('ADMIN_EMAIL');
		$this->session->unset_userdata('ADMIN_ROLE');		
		$this->session->sess_destroy();
		redirect('admin');
	}
	
	function check_admin_login($check_type)
	{
		if($check_type=='IS_LOGIN')
		{	
			$admin_id = $this->session->userdata('ADMIN_ID');
			if(!empty($admin_id))
			{
				redirect('admin/dashboard');
			}
		}
		if($check_type=='IS_NOT_LOGIN')
		{	
			$admin_id = $this->session->userdata('ADMIN_ID');
			if(empty($admin_id))
			{
				redirect('admin');
			}
		}
	}
}
