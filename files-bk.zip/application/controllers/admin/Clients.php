<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Clients extends CI_Controller 
{
	
	function __construct()
	{
		parent::__construct();
		$admin_id = $this->session->userdata('ADMIN_ID');
		if(empty($admin_id)){ redirect('admin'); }
	}	
	public function clients_images()
	{
		if(isset($_POST['submitform']))
		{
			if(isset($_FILES['image']['name']) && !empty($_FILES['image']['name']))
			{
				$allow_ext = array('png','jpg','jpeg','JPEG','gif');
				foreach($_FILES['image']['name'] as $key => $tmp_file)
				{
					$file_ext = image_extension($_FILES['image']['name'][$key]);
					if(in_array($file_ext,$allow_ext))
					{
						$file_name = create_image_unique($_FILES['image']['name'][$key]);
						$tmp_name = $_FILES['image']['tmp_name'][$key];
						$path = 'uploads/clients/'.$file_name;
						move_uploaded_file($tmp_name,$path);
						$img_data['image'] = $file_name;
						$this->clients_model->save_clients_images($img_data);											
					}
				}
			}
			$this->session->set_flashdata('msg','<div class="alert alert-success">image has been successfully added.</div>');
			redirect('admin/clients/clients_images');
		}
		
		$data['IMAGES'] = $this->clients_model->get_all_clients_images(); 
		$this->load->view('admin/clients/clients-images',$data);
	}

	function image_delete()
	{
		if(count($_POST) && isset($_POST['id']) && !empty($_POST['id']))
		{
			$this->clients_model->delete_clients_images($_POST['id']);
			delete_file('uploads/clients/',$_POST['image']);
			echo 1;
		}
		else
		{
			echo 0;
		}	
	}	
}