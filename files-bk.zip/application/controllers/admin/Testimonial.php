<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Testimonial  extends CI_Controller 
{
	
	function __construct()
	{
		parent::__construct();
		$admin_id = $this->session->userdata('ADMIN_ID');
		if(empty($admin_id))
		{
			redirect('admin');
		}
		$this->load->model('testimonial_model');
	}
	
	public function add_new()
	{
		if(isset($_POST['submitform']))
		{			
			$this->form_validation->set_rules('title', 'Title', 'trim|required');
			$this->form_validation->set_rules('status', 'Status', 'trim|required');
			$this->form_validation->set_error_delimiters('<div class="error"><i class="fa fa-warning"></i>&nbsp', '</div>');
			if ($this->form_validation->run() == TRUE)
			{
				$postdata = $this->input->post();
				if(isset($_FILES['image']['name']) && !empty($_FILES['image']['name']))
				{
					$allow_ext = array('png','jpg','jpeg','JPEG','gif');
					$file_ext = image_extension($_FILES['image']['name']);
					if(in_array($file_ext,$allow_ext))
					{
						$file_name = create_image_unique($_FILES['image']['name']);
						$tmp_name = $_FILES['image']['tmp_name'];
						$path = 'uploads/testimonials/'.$file_name;
						move_uploaded_file($tmp_name,$path);
						$postdata['image'] = $file_name;					
					}
				}
				unset($postdata['submitform']);
				$postdata['create_date'] = date('Y-m-d h:i:s');				
				$this->testimonial_model->add_testimonial($postdata);
				$this->session->set_flashdata('msg','<div class="alert alert-success">record has been successfully saved.</div>');
				redirect('admin/testimonial/listing');
			}				
		}		
		$this->load->view('admin/testimonial/add');
	}
	
	public function listing()
	{
		$data['RESULT'] = $this->testimonial_model->get_all_testimonial(); 
		$this->load->view('admin/testimonial/listing',$data);
	}
		
	public function edit()
	{
		$args = func_get_args();
		$data['RESULT'] = $this->testimonial_model->get_testimonial_by_id($args[0]); 
		
		if(isset($_POST['submitform']))
		{
			$postdata = $this->input->post();
			if(!empty($postdata['title']))
			{	
				if(isset($_FILES['image']['name']) && !empty($_FILES['image']['name']))
				{
					$allow_ext = array('png','jpg','jpeg','JPEG','gif');
					$file_ext = image_extension($_FILES['image']['name']);
					if(in_array($file_ext,$allow_ext))
					{
						$file_name = create_image_unique($_FILES['image']['name']);
						$tmp_name = $_FILES['image']['tmp_name'];
						$path = 'uploads/testimonials//'.$file_name;
						move_uploaded_file($tmp_name,$path);
						$postdata['image'] = $file_name;	
						delete_file('uploads/testimonials/',$postdata['old_file']);
					}
				}
				else
				{
					$postdata['image'] = $postdata['old_file'];
				}	
				unset($postdata['submitform']);
				unset($postdata['old_file']);
				$this->testimonial_model->update_testimonial_by_id($args[0],$postdata);
				$this->session->set_flashdata('msg','<div class="alert alert-success">record has been successfully updated.</div>');
				redirect('admin/testimonial/listing');				
			}	
		}		
		$this->load->view('admin/testimonial/edit',$data);
	}	
	
	public function delete_testimonial()
	{
		$args = func_get_args();
		$testimonial_data = $this->testimonial_model->get_testimonial_by_id($args[0]);
		$this->testimonial_model->delete_testimonial_by_id($args[0]);
		delete_file('uploads/testimonials/',$testimonial_data[0]->image);
		$this->session->set_flashdata('msg','<div class="alert alert-success">record has been successfully deleted.</div>');
		redirect('admin/testimonial/listing');
	}
	
}