<?php 
class Clients_model extends CI_Model
{	
	protected $table = 'tbl_clients';
	
	
	public function get_all_clients_images()
	{
		return $this->db->get('tbl_clients')->result();
	}
	public function save_clients_images($data)
	{
		$this->db->insert('tbl_clients',$data);
	}	
	function delete_clients_images($id)
	{
		$this->db->where('id',$id);
		$this->db->delete('tbl_clients');
	}
}
