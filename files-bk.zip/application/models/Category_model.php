<?php
class Category_model extends CI_Model
{
	protected $table = 'tbl_categories';
	/*start forum category model*/
	public function get_category_by_urlslug($key)
	{
		$this->db->where('url_slug',$key);
		return $this->db->get($this->table)->result();
	}
	public function save_category($data)
	{
		$this->db->insert($this->table,$data);
	}
	public function get_all_category()
	{
		//$this->db->order_by('parent_id','ASC');
		return $this->db->get($this->table)->result();
	}
	public function get_category_by_id($id)
	{
		$this->db->where('id',$id);
		return $this->db->get($this->table)->result();
	}
	public function update_category_by_id($id,$data)
	{
		$this->db->where('id',$id);
		$this->db->update($this->table,$data);
	}
	public function get_all_active_category()
	{
		$this->db->where('status',1);
		return $this->db->get($this->table)->result();
	}

	public function get_category_by_parent($id)
	{
		$this->db->where('parent_id',$id);
		return $this->db->get($this->table)->result();
	}
	public function delete_category_by_id($id)
	{
		$this->db->where('id',$id);
		$this->db->delete($this->table);
	}

	function get_all_child_category_with_count_product($parent_id)
	{
		$this->db->select('category.id, category.title, category.url_slug, count(product.id) as products');
		$this->db->from($this->table.' as category');
		$this->db->join('tbl_products as product','product.cat_id = category.id','left');
		$this->db->group_by('category.id');
		$this->db->where('category.parent_id',$parent_id);
		return $this->db->get()->result();
	}

	/* function get_all_child_category_with_count_product($parent_id)
	{
		$this->db->select('category.id, category.title, category.url_slug, count(product.id) as products');
		$this->db->from($this->table.' as category');
		$this->db->join('tbl_products as product','product.cat_id = category.id','left');
		$this->db->group_by('product.cat_id');
		$this->db->where('category.parent_id',0);
		return $this->db->get()->result();
	} */

	/*end forum category model*/

	public function get_all_child_category($parent_id,$level =0)
	{
		$this->db->where('parent_id',$parent_id);
		$query_data = $this->db->get($this->table)->result();
		if(count($query_data)>0)
		{
			$level++;
			foreach($query_data as $data)
			{
				//$selected = ($id!=0 && $id==$data->id)?'selected':'';
				echo '<option value="'.$data->id.'">';
				echo str_repeat('--',$level-1).' '.$data->title;
				$child = $this->check_child_category($data->id);
				if(count($child))
				{
					$this->get_all_child_category($data->id,$level);
				}
				echo '</option>';
			}
		}
	}

	public function get_all_child_category_for_admin($parent_id,$level =0)
	{   $cat_data = array();
		$this->db->where('id',$parent_id);
		$query_data = $this->db->get($this->table)->result();
		//return ($parent_id==0 && $level==0)?'Root':'';
		if(count($query_data)>0)
		{
			$level++;
			$oprator = ($level!=1)?' <strong> / </strong> ':'';
			array_push($cat_data,$query_data[0]->title);
			array_push($cat_data,$this->get_all_child_category_for_admin($query_data[0]->parent_id,$level));
		}
		return $cat_data;
		//return $data;
	}
	/*public function get_all_child_category($id,$level =0)
	{
		$this->db->where('parent_id',$id);
		$query_data = $this->db->get($this->table)->result();
		if(count($query_data)>0)
		{
			$level++;
			echo "<ul>";
			foreach($query_data as $data)
			{
				echo '<li>';
				echo $data->title;
				$child = $this->check_child_category($data->id);
				if(count($child))
				{
					$this->get_all_child_category($data->id);
				}
				echo '</li>';
			}
			echo "</ul>";
		}
	}*/

	public function check_child_category($id)
	{
		$this->db->where('parent_id',$id);
		return $this->db->get($this->table)->result();
	}

}
