<?php 
class Newslatter_model extends CI_Model
{	
	protected $table = 'tbl_newslatter';
	public function add_newslatter($data)
	{
		$this->db->insert($this->table,$data);
	}
	public function get_all_newslatter()
	{
		return $this->db->get($this->table)->result();
	}
	public function get_newslatter_by_id($id)
	{
		$this->db->where('id',$id);
		return $this->db->get($this->table)->result();
	}
	public function update_newslatter_by_id($id,$data)
	{
		$this->db->where('id',$id);
		$this->db->update($this->table,$data);
	}
	
	public function get_all_active_newslatter()
	{
		$this->db->where('status',1);
		return $this->db->get($this->table)->result();
	}
	public function delete_newslatter_by_id($id)
	{
		$this->db->where('id',$id);
		$this->db->delete($this->table);
	}
}
