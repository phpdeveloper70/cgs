<?php 
class Admin_model extends CI_Model{
	
	public function admin_login($email,$password)
	{
		$this->db->where('email',$email);
		$this->db->where('password',base64_encode($password));
		//$rows = $this->db->get('tbl_admin')->num_rows();
		$rows = $this->db->get('tbl_admin')->result();
		return $rows;
	}
	
	public function admin_login_by_email($email)
	{
		$this->db->where('email',$email);
		$rows = $this->db->get('tbl_admin')->result();
		return $rows;
	}
	
	public function admin_login_by_forgot_token($token)
	{
		$this->db->where('forgot_token',$token);
		$rows = $this->db->get('tbl_admin')->result();
		return $rows;
	}
	
	public function update_admin_by_id($id,$data)
	{
		$this->db->where('id',$id);
		$this->db->update('tbl_admin',$data);
	}
	
}
